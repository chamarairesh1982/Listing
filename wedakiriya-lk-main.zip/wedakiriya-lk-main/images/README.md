Placeholder directory for service images.
