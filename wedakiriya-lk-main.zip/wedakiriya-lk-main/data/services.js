window.servicesData = [
  {
    id: "abc-tailors",
    name: "ABC Tailors",
    city: "Colombo",
    phone: "0771234567",
    category: "tailor",
    description: "Professional tailoring services.",
    featured: true
  },,,,
  {
    id: "xyz-electricians",
    name: "XYZ Electricians",
    city: "Kandy",
    phone: "0719876543",
    category: "electrician",
    description: "Qualified electricians for all jobs.",
    featured: true
  },
  {
    id: "best-tutors",
    name: "Best Tutors",
    city: "Galle",
    phone: "0755555555",
    category: "tutor",
    description: "Private tutoring for all subjects.",
    featured: true
  },
  {
    id: "coolair-repairs",
    name: "CoolAir Repairs",
    city: "Negombo",
    phone: "0761111111",
    category: "ac",
    description: "Expert AC repair services.",
    featured: true
  },
  {
    id: "quick-tailor",
    name: "Quick Tailor",
    city: "Moratuwa",
    phone: "0722222222",
    category: "tailor",
    description: "Affordable stitching and alterations.",
    featured: false
  },
  {
    id: "city-electricians",
    name: "City Electricians",
    city: "Kurunegala",
    phone: "0777777777",
    category: "electrician",
    description: "Reliable home wiring services.",
    featured: false
  },
  {
    id: "quality-tutors",
    name: "Quality Tutors",
    city: "Anuradhapura",
    phone: "0701231234",
    category: "tutor",
    description: "Group and individual classes.",
    featured: false
  },
  {
    id: "coolfix-ac",
    name: "CoolFix AC",
    city: "Matara",
    phone: "0789999999",
    category: "ac",
    description: "Quick AC troubleshooting.",
    featured: false
  },
  {
    id: "sew-masters",
    name: "Sew Masters",
    city: "Jaffna",
    phone: "0741111111",
    category: "tailor",
    description: "Custom designs and uniforms.",
    featured: false
  },
  {
    id: "spark-electric",
    name: "Spark Electric",
    city: "Batticaloa",
    phone: "0712345678",
    category: "electrician",
    description: "Commercial and residential work.",
    featured: false
  },
  {
    id: "tutorpro",
    name: "TutorPro",
    city: "Colombo",
    phone: "0751112222",
    category: "tutor",
    description: "Exam focused tutoring.",
    featured: false
  },
  {
    id: "ac-express",
    name: "AC Express",
    city: "Gampaha",
    phone: "0762223333",
    category: "ac",
    description: "Same day AC service.",
    featured: false
  }
];
